#1
ss = "트와이스"

print("원본 문자열 ==>", ss)

#2
print("반대 문자열 ==> ", end='')

#3
print(ss[3], end='')
print(ss[2], end='')
print(ss[1], end='')
print(ss[0], end='')
