print("A님. 두 숫자 입력하세요")
num1 = int(input("정수1 ==>"))
num2 = int(input("정수2 ==>"))
hap = num1 + num2
print("결과 :", hap)

print("B님. 두 숫자 입력하세요")
num1 = int(input("정수1 ==>"))
num2 = int(input("정수2 ==>"))
hap = num1 + num2
print("결과 :", hap)

print("C님. 두 숫자 입력하세요")
num1 = int(input("정수1 ==>"))
num2 = int(input("정수2 ==>"))
hap = num1 + num2
print("결과 :", hap)
