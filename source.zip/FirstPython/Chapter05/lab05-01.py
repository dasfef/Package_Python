#1
age = int(input("나이를 입력 ==> "))

#2
if age >= 18 :
    print("즐거운 시간 되세요 ^^")
else :
    print("집에 갈 시간이네요!")
    
print("협조 감사합니다.")

