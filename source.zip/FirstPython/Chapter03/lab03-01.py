#1
pound = int(input("파운드(lb)를 입력하세요 : "))
kg = pound * 0.453592
print( pound, "파운드(lb)는", kg ,"킬로그램(kb)입니다")

#2
kg = int(input("킬로그램(kg)을 입력하세요 : "))
pound = kg * 2.204623
print( kg, "킬로그램(kg)은", pound ," 파운드(lb)입니다")
