## 함수 정의 부분
def func2() :
    result = 100
    return result

## 전역 변수 선언 부분
hap = 0

## 메인 코드 부분
hap = func2()
print("func2()에서 돌려준 값 ==> ", hap)
