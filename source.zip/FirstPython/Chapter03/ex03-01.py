num1 = int(input("나눠지는 수 ==> "))
num2 = int(input("나누는 수 ==> "))

q = num1 // num2
r = num1 % num2

print(num1, '을(를)', num2, '(으)로 나눈 몫은 ', q, '입니다.')
print(num1, '을(를)', num2, '(으)로 나눈 나머지는 ', r, '입니다.')
