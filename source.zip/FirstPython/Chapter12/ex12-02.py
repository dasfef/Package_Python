from tkinter import *
root = Tk()


root.title("창 조절 연습")

root.geometry("500x200")

root.resizable(width=FALSE, height=FALSE)

root.mainloop()
