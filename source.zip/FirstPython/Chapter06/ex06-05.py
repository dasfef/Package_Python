hap = 0
num1, num2 = 0, 0

while True :
    num1 = int(input("숫자1 ==> "))
    num2 = int(input("숫자2 ==> "))

    hap = num1 + num2
    print(num1, "+", num2, "=", hap)
