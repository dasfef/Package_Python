#1
i = 0 
k = 0

#2
for i in range(2, 10, 1) :
    for k in range(1, 10, 1) :
        print(i, " X ", k, " = ", i*k)
    print("")
