#1
num1 = int(input("숫자1 ==>"))
num2 = int(input("숫자2 ==>"))

#2
result1 = num1 + num2
result2 = num1 - num2
result3 = num1 * num2
result4 = num1 / num2
result5 = num1 % num2
result6 = num1 ** num2

#3
print(num1 , "+" , num2 , "=" , result1)
print(num1 , "-" , num2 , "=" , result2)
print(num1 , "*" , num2 , "=" , result3)
print(num1 , "/" , num2 , "=" , result4)
print(num1 , "%" , num2 , "=" , result5)
print(num1 , "**" , num2 , "=" , result6)
