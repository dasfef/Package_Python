score = int(input("필기 시험점수를 입력하세요 ==>"))
print(score >= 70)
