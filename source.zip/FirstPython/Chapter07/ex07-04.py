numList2 = [ [ 1,  2,  3,  4] ,
                 [ 5,  6,  7,  8] ,
                 [ 9, 10,  11, 12] ]
 
for i in range(0, 3) :
    for k in range(0, 4) :
        print(" ", numList2[i][k], end ="")
    print("")
