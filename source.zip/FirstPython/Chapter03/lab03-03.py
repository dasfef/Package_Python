#1
python = 3
mobile = 2
excel = 1

#2
A = 4.5
A0 = 4.0
B = 3.5

#3
avg = ((python * B) + (mobile * A0) + (excel * A)) / (python + mobile + excel)

#4
print("평균 학점 : ", avg)
