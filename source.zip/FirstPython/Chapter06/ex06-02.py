i = 0

for i in range(1, 11, 1) :
    hap = hap + i
    
print("1에서 10까지의 합 : , hap)
