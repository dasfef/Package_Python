num = 200

if num < 100 :
    print("100보다 작군요.")
    print("여기는 참입니다.")
else :
    print("100보다 크군요.")
    print("여기는 거짓입니다.")
    
print("프로그램 끝!")
