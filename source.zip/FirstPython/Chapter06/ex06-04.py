i, hap = 0, 0

for i in range(1001, 2001, 2) :
    hap += i

print("1000에서 2000까지의 홀수의 합 :", hap)
