#1
total = 0

#2
total -= 900*10
total -= 3500*5

#3
total += 1800*2
total += 4000*4
total += 1500
total += 2000*4
total += 1800*5

#4
print("오늘 총 매출액은 ", total, "원입니다")
