num1, num2, num3, num4 = 0, 0, 0, 0
hap = 0

num1 = int(input("숫자 : "))
num2 = int(input("숫자 : "))
num3 = int(input("숫자 : "))
num4 = int(input("숫자 : "))

hap = num1+ num2 + num3 + num4

print("합계 ==> " ,hap)
