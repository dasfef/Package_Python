print("\난생 처음")
print("\\난생 처음")
print("\ ")
print("\")
