num = 99
if  num < 100 :
    print("100보다 작습니다.")
