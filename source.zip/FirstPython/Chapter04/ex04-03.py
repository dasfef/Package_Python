var1 = input("첫번째 문자열 ==>")
var2 = input("두번째 문자열 ==>")

len1 = len(var1)
len2 = len(var2)

diff = len1 - len2

print("두 문자열의 길이차이는", diff," 입니다.")
