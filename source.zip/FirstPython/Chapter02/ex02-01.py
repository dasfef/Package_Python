userName = input("이름 ==> ")
userPhone = input("전화번호 ==> ")

print("제 이름은 ", userName, "이고, 연락처는", userPhone , "입니다.")
