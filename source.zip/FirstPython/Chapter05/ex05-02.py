num=200

if num > 100 :
    print("100보다 ")
    print("큽니다.")
    
print("프로그램 끝")
