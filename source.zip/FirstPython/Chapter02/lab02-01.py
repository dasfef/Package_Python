#2
num1 = 100
num2 = 200

#3
result1 = num1 + num2
result2 = num1 - num2
result3 = num1 * num2
result4 = num1 / num2

#4
print(num1 , "+" , num2 , "=" , result1)
print(num1 , "-" , num2 , "=" , result2)
print(num1 , "*" , num2 , "=" , result3)
print(num1 , "/" , num2 , "=" , result4)
