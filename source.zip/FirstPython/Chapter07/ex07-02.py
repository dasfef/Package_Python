numList = [0, 0, 0, 0]
hap = 0

numList[0] = int(input("숫자 : "))
numList[1] = int(input("숫자 : "))
numList[2] = int(input("숫자 : "))
numList[3] = int(input("숫자 : "))

hap = numList[0] + numList[1] + numList[2] + numList[3]

print("합계 ==> " ,hap)
