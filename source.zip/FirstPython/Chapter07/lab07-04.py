#1
singer = {}

#2
singer['이름'] = "트와이스"
singer['구성원수'] = 9
singer['데뷰'] = "서바이벌 식스틴"
singer['대표곡'] = "CRY FOR ME"

#3
for k in singer.keys() :
    print(k, " ==> ", singer[k])
