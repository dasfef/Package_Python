from tkinter import *

root = Tk()

# 이 부분에서 컨트롤을 배치

root.mainloop()
